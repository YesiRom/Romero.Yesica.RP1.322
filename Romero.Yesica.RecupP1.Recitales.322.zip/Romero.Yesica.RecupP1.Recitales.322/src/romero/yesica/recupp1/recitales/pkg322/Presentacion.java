
package romero.yesica.recupp1.recitales.pkg322;

import java.util.Objects;


public abstract class Presentacion {
     private String nombre;
    private String escenario;
    private TipoEscenario tipoEscenario;

    public Presentacion(String nombre, String escenario, TipoEscenario tipoEscenario) {
        this.nombre = nombre;
        this.escenario = escenario;
        this.tipoEscenario = tipoEscenario;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEscenario() {
        return escenario;
    }

    public TipoEscenario getTipoEscenario() {
        return tipoEscenario;
    }
    
    
    
     @Override
    public int hashCode() {
        return Objects.hash(nombre, escenario);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof Presentacion p)) {
            return false;
        }
        return nombre.equals(p.nombre) && escenario.equals(p.escenario);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
         sb.append("_____________________________\n").append("Nombre: ").append(nombre).append("\nEscenario: ").append(escenario).append("\nTipo De Escenario: ").append(tipoEscenario);
        return sb.toString();
    }
    
    
}

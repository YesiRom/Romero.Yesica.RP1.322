
package romero.yesica.recupp1.recitales.pkg322;


public interface ITocableEnVivo {
    String tocarEnVivo();
}

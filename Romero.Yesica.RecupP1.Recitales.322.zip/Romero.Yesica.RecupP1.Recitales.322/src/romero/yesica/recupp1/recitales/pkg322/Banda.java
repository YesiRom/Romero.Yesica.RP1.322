
package romero.yesica.recupp1.recitales.pkg322;


public class Banda extends Presentacion implements ITocableEnVivo{
    int cantidadIntegrantesMax;
    public Banda(String nombre, String escenario, TipoEscenario tipoEscenario, int integrantesMax) {
        super(nombre, escenario, tipoEscenario);
    }

    @Override
    public String tocarEnVivo() {
        return "La Banda " + getNombre()+ " esta tocando en vivo en el escenario " + getEscenario();
    }
    
    @Override
    public String toString() {
        return super.toString() + "\nCantidad de Integrantes: " + cantidadIntegrantesMax;
    }
}

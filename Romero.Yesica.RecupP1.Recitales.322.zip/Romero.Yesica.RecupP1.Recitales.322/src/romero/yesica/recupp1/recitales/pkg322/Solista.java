
package romero.yesica.recupp1.recitales.pkg322;


public class Solista extends Presentacion implements IAnimable, ITocableEnVivo{
    private String instrumentoPrincipal;

    public Solista(String nombre, String escenario, TipoEscenario tipoEscenario, String instrumento) {
        super(nombre, escenario, tipoEscenario);
    }

    @Override
    public String animarAlPublico() {
         return "El solista " + getNombre()+ " esta animando en el escenario " + getEscenario();
    }

    @Override
    public String tocarEnVivo() {
         return "El solista " + getNombre()+ " esta tocando en vivo en el escenario " + getEscenario();
    }

    @Override
    public String toString() {
        return super.toString() + "\nInstrumento Principal: " + instrumentoPrincipal;
    }
    
    
}

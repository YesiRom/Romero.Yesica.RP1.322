
package romero.yesica.recupp1.recitales.pkg322;


public class Djs extends Presentacion implements IAnimable{
    private String estiloMusical;
    
    public Djs(String nombre, String escenario, TipoEscenario tipoEscenario, String estilo) {
        super(nombre, escenario, tipoEscenario);
    }

    @Override
    public String animarAlPublico() {
          return "El djs " + getNombre()+ " esta animando en el escenario " + getEscenario();
    }
    
    @Override
    public String toString() {
        return super.toString() + "\nEstilo Musical: " + estiloMusical;
    }
}

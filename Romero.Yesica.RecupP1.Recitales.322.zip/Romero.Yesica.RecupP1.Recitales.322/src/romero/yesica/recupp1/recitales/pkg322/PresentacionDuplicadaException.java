
package romero.yesica.recupp1.recitales.pkg322;


public class PresentacionDuplicadaException extends RuntimeException{
    private static final String MENSAJE = "Presentacion Duplicada, ya existe";

    public PresentacionDuplicadaException() {
        this(MENSAJE);
    }

    public PresentacionDuplicadaException(String mensaje) {
        super(mensaje);
    }
}

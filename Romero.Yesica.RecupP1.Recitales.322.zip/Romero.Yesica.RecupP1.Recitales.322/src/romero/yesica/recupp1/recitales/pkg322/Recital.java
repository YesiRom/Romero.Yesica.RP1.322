
package romero.yesica.recupp1.recitales.pkg322;

import java.util.ArrayList;
import java.util.List;


public class Recital {
    private List <Presentacion> presentaciones;

    public Recital() {
        this.presentaciones = new ArrayList<>();
    }
    
    public void agregarPresentacion(Presentacion nuevaPresentacion){
        validarPresentacionNoNull(nuevaPresentacion);
        validarProyectoDuplicado(nuevaPresentacion);
        presentaciones.add(nuevaPresentacion);
    }
   
     private void validarPresentacionNoNull(Presentacion nuevaPresentacion) {
        if(nuevaPresentacion == null){
            throw new IllegalArgumentException("La presentacion es nula");
        }
    }
     
     private void validarProyectoDuplicado(Presentacion presentacion) {
        if (presentaciones.contains(presentacion)) {
            throw new PresentacionDuplicadaException();
        }
       
    }
     
    
     public String mostrarPresentaciones(){
         StringBuilder sb = new StringBuilder("********  PRESENTACIONES DEL RECITAL *********** \n");
         
         for(Presentacion p : presentaciones){
             sb.append(p).append("\n");
         }
         return sb.toString();
     }
     
       public String  tocarEnVivo(){
         StringBuilder sb = new StringBuilder();
         
          for(Presentacion pro : presentaciones){
              if(pro instanceof ITocableEnVivo p){
                  sb.append(p.tocarEnVivo());
              }else {
                  sb.append("Los djs :  ").append(pro.getNombre()).append(", no pueden tocar en vivo");
              }
             sb.append("\n");
            }
          return sb.toString();
     }
       
        public String  animarPublico(){
         StringBuilder sb = new StringBuilder();
         
          for(Presentacion pro : presentaciones){
              if(pro instanceof IAnimable p){
                  sb.append(p.animarAlPublico());
              }else {
                  sb.append("Las bandas :  ").append(pro.getNombre()).append(", no pueden animar al publico");
              }
             sb.append("\n");
            }
          return sb.toString();
     }
       
        public String filtrarPorTipoEscenario(TipoEscenario tipo){
            StringBuilder sb = new StringBuilder("Presentaciones en :").append(tipo).append("\n");
            
            for(Presentacion p : presentaciones){
                if(p.getTipoEscenario() == tipo){
                    sb.append(p);
                }
            }
            return sb.toString();
        }
       
       
}

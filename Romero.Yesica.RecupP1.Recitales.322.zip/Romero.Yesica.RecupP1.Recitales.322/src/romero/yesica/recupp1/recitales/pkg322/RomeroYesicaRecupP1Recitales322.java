
package romero.yesica.recupp1.recitales.pkg322;


public class RomeroYesicaRecupP1Recitales322 {


    public static void main(String[] args) {
        
        Recital recital = new Recital();
    
   //Caso de prueba: intenta agregar una presentacion duplicada, mismo  escenario
        
try {
            
            recital.agregarPresentacion(new Banda("Los Piojos", "Escenario Principal", TipoEscenario.EXTERIOR, 5));
            recital.agregarPresentacion(new Solista("Julieta Benegas", "Escenario Interior", TipoEscenario.INTERIOR, "Guitarra"));
            recital.agregarPresentacion(new Djs("DJ Tech", "Escenario Plaza", TipoEscenario.EXTERIOR, "Techno"));

           
            recital.agregarPresentacion(new Banda("Los Piojos", "Escenario Principal", TipoEscenario.EXTERIOR, 6));
        } catch (PresentacionDuplicadaException e) {
            System.out.println("Excepción: " + e.getMessage());
        }

//Muestra las presentaciones del recital
        System.out.println(recital.mostrarPresentaciones());    
        
 // metodo tocar en vivo
 
    System.out.println(recital.tocarEnVivo());   
 
 //presentaciones segun el tipo de ecenario
   System.out.println(recital.filtrarPorTipoEscenario(TipoEscenario.INTERIOR));  
        
    }
    
 
     
}

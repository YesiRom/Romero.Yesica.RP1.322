
package romero.yesica.recupp1.recitales.pkg322;


public enum TipoEscenario {
    INTERIOR,
    EXTERIOR;
}
